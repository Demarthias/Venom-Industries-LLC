LagSlayer — Kill Ping. Boost Stability.

USAGE:
  sudo ./lagslayer.sh gaming
  sudo ./lagslayer.sh streaming
  sudo ./lagslayer.sh dev
  sudo ./lagslayer.sh reset

TIP:
  For fastest name lookups, set your router DNS to 1.1.1.1, 8.8.8.8.
